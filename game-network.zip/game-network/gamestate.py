import sys

class GameState:
    def __init__(self):
        self.players = dict()

    def update(self, name, addr, port):
        self.players[name] = [addr, port]

    def get_players(self):
        return self.players
    
    def to_string(self):
        retval = ""
        for key, value in self.players:
            retval += value.to_string() + ":"

        return retval
import pygame as pg
import socket
import sys
from constants import *
from gamestate import *
from sprites import *
# from main import Game

HOST = 'localhost'
PORT = 8888

class GameServer:

    def __init__(self):
        print('Game created')
        self.num_of_players = 1
        self.player_count = 0
        self.game_stage = WAITING_FOR_PLAYERS
        self.game_state = GameState()

    def create_socket(self):
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            print('Successfully created socket.')
            return s
        except socket.error as e:
            print(e)
            sys.exit() 

    def bind_socket(self, s):
        try:
            s.bind((HOST, PORT))
            print('Successfully binded socket to host and port.')
            return s
        except socket.error as e:
            print(e)
            sys.exit()
      
    # send data to all players
    def broadcast(self, s, msg):
        d = self.game_state.get_players()
        # for key, value in d.items:
        #     player = value
        #     self.send(s, player, msg)
        print(d)
        for key in d:
            player = d[key] # access the list containing addr, port of client
            # print(d[key])
            self.send(s, player, msg)

    # sending data to player
    def send(self, s, player, msg):
        msg = msg.encode()
        addr = player[0]
        port = player[1]
        try:
            s.sendto(msg,(addr, port))
        except socket.error as e:
            print(e)

    def run(self, s):
        while True:
            try:
                # Get data from player
                data, addr_port = s.recvfrom(1024)
                print("Data received from player")
                print("{} : {}".format(addr_port, data.decode(encoding="utf-8").strip()))
                player_data = data.decode(encoding="utf-8").strip()
            except socket.error as e:
                print(e)

            if self.game_stage == WAITING_FOR_PLAYERS:
                print("Waiting for players...")
                if player_data.startswith("CONNECT"):
                    addr = addr_port[0]
                    port = addr_port[1]
                    print('Player connected')
                    self.game_state.update('Player', addr, port)
                    self.broadcast(s, "CONNECTED " + "Player")
                    self.player_count += 1
                    if self.player_count == self.num_of_players:
                        self.game_stage = GAME_START
            elif self.game_stage == GAME_START:
                self.broadcast(s, "START")
                self.game_stage == IN_PROGRESS
            elif self.game_stage == IN_PROGRESS:
                if player_data.startswith("PLAYER"):
                    print("In progress....")
                    # player_info = player_data.split(" ")
                    # player = self.game_state.get_players()[player_info[1]]
                    # player.update()
                    # self.game_state.update("Player ", player)
                    self.broadcast(self.game_state.to_string())

g_server = GameServer() 
s = g_server.create_socket()
s = g_server.bind_socket(s)
# s.settimeout(100)
while True:
    g_server.run(s)

s.close()



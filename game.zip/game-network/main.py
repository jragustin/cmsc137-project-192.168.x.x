import pygame as pg
import sys
from os import path
import socket
from settings import *
from sprites import *
from trackmap import *
# import threading
import time

HOST = 'localhost'

class Game:
    def __init__(self):
        pg.init()

        if(len(sys.argv) != 3):
            print('Usage: python3 main.py <server> <player name>')
            sys.exit()
        else:
            self.server = sys.argv[1]
            self.name = sys.argv[2]
            print(self.server)
            print(self.name)

        self.screen = pg.display.set_mode((WIDTH, HEIGHT))
        pg.display.set_caption(TITLE+': '+self.name)

        # # game timer 
        # t = threading.Thread()
        # t.start() # time to play

        self.clock = pg.time.Clock()
        pg.key.set_repeat(500, 100)
        self.load_data()
        self.connected = False

    def create_socket(self):
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            print("Successfully created socket.")
            return s
        except socket.error:
            print('Failed to create socket')
            sys.exit()

    # sending data to server
    def send(self, s, msg):
        # print(msg)
        msg = msg.encode()
        try:
            s.sendto(msg,(self.server, 8888))
        except socket.error as e:
            print(e)


    def load_data(self):
        game_folder = path.dirname(__file__)
        self.map = Map(path.join(game_folder, "map.txt"))

    def new(self):
        # initialize all variables and do all the setup for a new game
        self.all_sprites = pg.sprite.Group()
        self.walls = pg.sprite.Group()
        for row, tiles in enumerate(self.map.data):
            for col, tile in enumerate(tiles):
                if tile == '1':
                    Wall(self, col, row)
                # if tile == 'P':
                #     self.player = Player(self, col, row)
        self.camera = Camera(self.map.width, self.map.height)

    def run(self, s):
        # game loop - set self.playing = False to end the game
        self.playing = True
        self.send(s,"")
        while self.playing:
            # time.sleep(1)
            try:
                data, addr_port = s.recvfrom(1024) # get data from server
                # print("Data received from server")
                print("{} : {}".format(addr_port, data.decode()))
                server_data = data.decode()
            except socket.error as e:
                print(e)
           
            if self.connected == False and server_data.startswith("CONNECTED"):
                self.connected = True
                print("Connected")
                self.send(s,"")
            elif self.connected == False:
                print("Connecting ...")
                print(server_data)
                self.player = Player(self, 10, 10, self.name)
                self.send(s,"CONNECT "+self.name)
            elif self.connected == True:
                self.draw()
                if server_data.startswith("PLAYER"): 
                    self.dt = self.clock.tick(FPS) / 1000
                    self.events()
                    self.update()
                    # player_info = server_data.split(":")
                else:
                    self.send(s, "PLAYER")

    def quit(self):
        pg.quit()
        sys.exit()

    def update(self):
        # update portion of the game loop
        self.all_sprites.update()
        self.send(s, "PLAYER " + self.name)
        self.camera.update(self.player)


    def draw_grid(self):
        for x in range(0, WIDTH, TILESIZE):
            pg.draw.line(self.screen, LIGHTGREY, (x, 0), (x, HEIGHT))
        for y in range(0, HEIGHT, TILESIZE):
            pg.draw.line(self.screen, LIGHTGREY, (0, y), (WIDTH, y))

    def draw(self):
        self.screen.fill(BGCOLOR)
        self.draw_grid()
        # self.all_sprites.draw(self.screen)
        for sprite in self.all_sprites:
            self.screen.blit(sprite.image, self.camera.apply(sprite))
        pg.display.flip()

    def events(self):
        # catch all events here
        for event in pg.event.get():
            if event.type == pg.QUIT:
                self.send(s, self.name+' left the game')
                self.quit()
            if event.type == pg.KEYDOWN:
                if event.key == pg.K_ESCAPE:
                    self.send(s, self.name+' left the game')
                    self.quit()


    def show_start_screen(self):
        pass

    def show_go_screen(self):
        pass


# create the game object
g = Game()
g.show_start_screen()
s = g.create_socket()
# s.settimeout(100)
while True:
    g.new()
    print("Sprites loaded into the map")
    g.run(s)
    print("Map drawn")
    g.show_go_screen()
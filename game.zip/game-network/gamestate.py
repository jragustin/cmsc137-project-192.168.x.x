import sys

class GameState:
    def __init__(self):
        self.players = dict()

    def update(self, name, addr, port):
        self.players[name] = [addr, port]

    def get_players(self):
        return self.players
    
    def to_string(self):
        retval = ""
        d = self.players
        for key in d:
            retval += "PLAYER " + key + ": "

        return retval
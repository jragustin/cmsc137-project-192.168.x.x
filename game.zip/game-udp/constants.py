# define game stage constants
GAME_START = 0
IN_PROGRESS = 1
WAITING_FOR_PLAYERS = 2
GAME_END = 3

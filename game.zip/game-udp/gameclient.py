import socket
import sys


HOST = 'localhost'
PORT = 8888

class Client:
  
    def __init__(self):
        print('Hello')

    def create_socket(self):
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            return s
        except socket.error:
            print('Failed to create socket')
            sys.exit()

    def run(self, s):
        msg = input('Enter message: ')
        msg = msg.encode()
        try:
            s.sendto(msg,(HOST, PORT))
            data, ip = s.recvfrom(1024)

            print("{} : {}".format(ip, data.decode()))
        except socket.error as e:
            print(e)
            sys.exit()

g_client = Client()
s = g_client.create_socket()
while True:
    g_client.run(s)
